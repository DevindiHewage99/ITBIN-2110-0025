<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
	
	header('location:login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
	<h3>about us</h3>
	<p> <a href="home.php">home</a> / about</p>
</div>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="images/about-img.jpg" alt="">
      </div>

      <div class="content">
         <h3>why choose us?</h3>
         <p>At BookBar, We strive to create a seamless browsing experience, where you can effortlessly discover new authors, genres, and hidden gems.
			With our user-friendly interface and secure payment gateway, you can easily indulge in the joy of book hunting from the comfort of your own home.
			Join our community of book lovers, and let the pages transport you to extraordinary worlds, inspire your imagination, and ignite your passion for reading.</p>
		 <p>Happy reading!</p>
		 
		 
         <a href="contact.php" class="btn">contact us</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="title">client's reviews</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/pic-3.png" alt="">
         <p>The BookBar is a game-changer, providing a user-friendly interface, extensive book collection, efficient search, 
		 and prompt delivery. Highly recommended for convenient.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Shehan Gajadeera</h3>
      </div>
	  
	   <div class="box">
         <img src="images/pic-6.png" alt="">
         <p>The BookBar is fantastic! with personalized recommendations and excellent customer support. 
		 It's my go-to platform for all my book purchases!</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Kiyara Fernando</h3>
      </div>
	  
	    <div class="box">
         <img src="images/pic-5.png" alt="">
         <p>The BookBar is a bookworm's paradise! Extensive library, pre-order upcoming titles, easy navigation, hidden literary gems. 
		 Must-visit for book lovers!</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Tishan D Silva</h3>
      </div>
	  
	  <div class="box">
         <img src="images/pic-2.png" alt="">
         <p>The BookBar offers exceptional shopping! Sleek interface, effortless browsing, social media integration for sharing favorite reads.
		 Highly recommended for convenience and superb selection!</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Shyni perera</h3>
      </div>
	  
	   <div class="box">
         <img src="images/pic-1.png" alt="">
         <p>The BookBar is amazing! User-friendly interface, vast selection of books, effortless browsing, exceptional customer service. Highly recommended for convenience, selection, 
		 and overall excellence!</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Adithya Mahanama</h3>
      </div>
	  
	   <div class="box">
         <img src="images/pic-4.png" alt="">
         <p>The BookBar is incredible! Endless possibilities, spot-on personalized recommendations, flexibility in e-book or physical copies, prompt and reliable delivery. 
		 Redefining my reading experience!</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Tisuni Ranasinghe</h3>
      </div>
	  
	  
	</div>

</section>

<section class="authors">

	<h1 class="title">greate authors</h1>
	
	<div class="box-container">
	
		<div class="box">
			<img src="images/author-3.jpg" alt="">
			<div class="share">
				<a href="#" class="fab fa-facebook-f"></a>
				<a href="#" class="fab fa-twitter"></a>
				<a href="#" class="fab fa-instagram"></a>
				<a href="#" class="fab fa-linkedin"></a>
			</div>
			<h3>Rayan D Silva</h3>
		</div>
		
		<div class="box">
			<img src="images/author-6.jpg" alt="">
			<div class="share">
				<a href="#" class="fab fa-facebook-f"></a>
				<a href="#" class="fab fa-twitter"></a>
				<a href="#" class="fab fa-instagram"></a>
				<a href="#" class="fab fa-linkedin"></a>
			</div>
			<h3>Taniya Joden</h3>
		</div>
		
		<div class="box">
			<img src="images/author-5.jpg" alt="">
			<div class="share">
				<a href="#" class="fab fa-facebook-f"></a>
				<a href="#" class="fab fa-twitter"></a>
				<a href="#" class="fab fa-instagram"></a>
				<a href="#" class="fab fa-linkedin"></a>
			</div>
			<h3>Sayen Leo</h3>
		</div>
		
		<div class="box">
			<img src="images/author-2.jpg" alt="">
			<div class="share">
				<a href="#" class="fab fa-facebook-f"></a>
				<a href="#" class="fab fa-twitter"></a>
				<a href="#" class="fab fa-instagram"></a>
				<a href="#" class="fab fa-linkedin"></a>
			</div>
			<h3>Shehana Peris</h3>
		</div>
		
		<div class="box">
			<img src="images/author-1.jpg" alt="">
			<div class="share">
				<a href="#" class="fab fa-facebook-f"></a>
				<a href="#" class="fab fa-twitter"></a>
				<a href="#" class="fab fa-instagram"></a>
				<a href="#" class="fab fa-linkedin"></a>
			</div>
			<h3>Androo Jeson</h3>
		</div>
		
		<div class="box">
			<img src="images/author-4.jpg" alt="">
			<div class="share">
				<a href="#" class="fab fa-facebook-f"></a>
				<a href="#" class="fab fa-twitter"></a>
				<a href="#" class="fab fa-instagram"></a>
				<a href="#" class="fab fa-linkedin"></a>
			</div>
			<h3>Keshu Lineya</h3>
		</div>
	
	</div>

</section>







<?php include 'footer.php'; ?>

<!-- custom js file link -->

<script src="js/script.js"></script>


</body>
</html>
